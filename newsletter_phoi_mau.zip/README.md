# Bài tập phối màu Newsletter

## 2 phiên bản
- `newsletter_version1.html`: xanh dương + xanh ngọc + vàng cam
- `newsletter_version2.html`: tím đậm + hồng đậm + xanh teal

Cả hai phiên bản sử dụng Bootstrap 5.3.3 và biến CSS để quản lý màu.

## Mã màu
### Version 1
- Primary: #2563EB
- Secondary: #14B8A6
- Accent: #F59E0B

### Version 2
- Primary: #4C1D95
- Secondary: #BE185D
- Accent: #0F766E

## Cách chạy
Mở trực tiếp một trong hai file `.html` bằng trình duyệt.

## Nộp bài
Đưa hai file lên GitHub hoặc CodePen và nộp link repository/CodePen.
